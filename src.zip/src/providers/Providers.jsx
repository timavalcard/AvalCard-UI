"use client";

import { ResponsiveProvider } from "@/context/ResponsiveProvider";

const Providers = ({ children }) => {
  return <ResponsiveProvider>{children}</ResponsiveProvider>;
};

export default Providers;
