import MarqueeTop from "@/components/ui/main/home/MarqueeTop";

export default function Home() {
    return (
        <>
            <div className="container">
                <div className="text-center title-header">
                    در تمامی مسیر با ما خواهید بود.
                </div>
                <div className="text-muted-5 font-medium max-w-[650px] mx-auto text-center">
                    اگر میخواهید با گروه ما اشنا بشوید صفحه درباره ما را مطالعه کنید و راجب سیاست های کاری و اخلاقی ما نظرات اینده ساز بدید خوشحال میشویم با شما در ارتباط باشیم.
                </div>
            </div>

            <MarqueeTop />

        </>
    )
}