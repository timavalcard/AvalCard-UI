export default function Page() {
    return(
        <>
        contact us
        </>
    );
}