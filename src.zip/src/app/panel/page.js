import Panel from "@/components/ui/panel/Panel";

export default function Home() {
  return (
      <Panel/>
  );
}
