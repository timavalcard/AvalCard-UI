import React from "react";

const Button = ({ size = "md", color = "green", children, classNme, outline, ...rest }) => {
    const sizes = {
        sm: "h-[2rem] w-[8rem] text-[.875rem]",
        md: "h-[3.125rem] w-[9.5rem] text-[1rem]",
        lg: "h-[3.125rem] w-[15rem] text-[1rem]",
        xl: "h-[3.125rem] w-full max-w-[18.125rem] text-[1rem] ",
        '2xl': "h-[3.125rem] w-full max-w-[23.125rem] text-[1rem] ",
        full: 'w-full h-[3.125rem] text-[1rem]'
    };

    const colors = {
        blue: "border-blue-600 bg-blue-600 hover:bg-blue-700 hover:border-blue-700 text-white",
        red: "border-red-600 bg-red-600 hover:bg-red-700 hover:border-red-700 text-white",
        green: "border-green-light bg-green-light hover:bg-emerald-400 hover:border-emerald-400 text-white",
        light: "text-blue-500 bg-transportant !border-0",
        gray: "border-gray-400 bg-gray-400 hover:bg-gray-500 text-white"
    };

    const outlineColors = {
        blue: "border-blue-600  hover:bg-blue-600 hover:text-white text-blue-600",
        red: "border-red-600 bg-red-600 hover:bg-red-700 text-white",
        green: "border-green-600 bg-green-600 hover:bg-green-700 text-white",
        light: "text-blue-500 bg-transportant !border-0",
        gray: "border-gray-400 bg-gray-400 hover:bg-gray-500 text-white"
    }

    return (
        <button
            {...rest}
            className={`border rounded-2lg p-0 grid items-center transition-all ${sizes[size]} ${outline ? outlineColors[color] : colors[color]} ${classNme}`}
        >
            {children}
        </button>
    );
};

export default Button;