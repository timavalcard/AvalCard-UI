import { forwardRef, useId } from "react";
import styles from "./Input.module.css";

const Input = forwardRef(
  (
    {
      className,
      icon,
      iconRight,
      error,
      placeholder,
      disabled = false,
      labelClassName,
      height = "h-[3.025rem]",
      isTextarea = false,
      ...rest
    },
    ref
  ) => {
    const id = useId();
    
    const commonClasses = `
      ${height} w-full px-[12px] transition border border-[#1A2531] border-opacity-15 rounded-[10px] text-black placeholder-muted focus:outline-greenLight
      ${icon ? "!pl-[38px]" : ""}
      ${iconRight ? "!pr-[36px]" : ""}
      ${disabled ? "bg-gray-100" : ""}
      ${error ? "!border-red-500 focus:outline-red-500 is-invalid" : ""}
      ${className || ""}
      ${styles.input}
    `;

    return (
      <div className={`${height} relative grid items-center w-full !p-0 ${styles.box}`}>
        {icon && <div className="absolute left-[18px]">{icon}</div>}

        {isTextarea ? (
          <textarea
            ref={ref}
            id={id}
            disabled={disabled}
            placeholder=""
            className={`py-2.5 resize-none scrollbar-hide ${commonClasses}`}
            {...rest}
          />
        ) : (
          <input
            ref={ref}
            id={id}
            disabled={disabled}
            placeholder=""
            className={`py-0 ${commonClasses}`}
            {...rest}
          />
        )}

        {iconRight && <div className="absolute right-[12px]">{iconRight}</div>}

        <label
          htmlFor={id}
          className={`absolute top-[50%] text-xs !p-0 !m-0 translate-y-[-50%] text-muted ${styles.label} ${
            iconRight ? "right-[36px]" : "right-[12px]"
          } ${labelClassName || ""}`}
        >
          <div>{placeholder}</div>
        </label>
      </div>
    );
  }
);

export default Input;
