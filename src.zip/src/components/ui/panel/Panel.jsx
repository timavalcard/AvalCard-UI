import Card from '@/components/ui/globals/card/Card'
import More from '@/components/ui/globals/More'
import styles from './Panel.module.css'
export default function Panel() {

    return (
        <div className={`my-8`}>
            <div className={`bg-[#42DB9B] ${styles.box}`}></div>
            <div className={`flex mt-custom-4`}>
                <div className={`${styles.newProduct} section relative items-center grid`}>
                    <div className={`flex justify-between items-center huge-text-little-bold`}>
                        <div className={`!mb-0 text-[#2E2E2E]`}>محصولات جدید</div>
                        <More />
                    </div>
                    <div className='grid xl:grid-cols-3 grid-cols-2 items-center xl:gap-[30px] gap-[12px]'>
                        <div className={`${styles.rightArrow}`}>
                            <svg width="10" height="17" viewBox="0 0 10 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.28394 1.56427L7.46789 7.22917C8.19821 7.89818 8.19821 8.99293 7.46789 9.66195L1.28394 15.3268"
                                      stroke="#959595" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div className={`grid justify-center items-center py-10 px-3 ${styles.boxProductSelect}`}>
                            <div className='grid justify-center items-center'>
                                <img src="/images/boat.svg" alt=""/>
                            </div>
                            <div className={``}>
                                <p className={`text-little-bold`}>پکیج اکانت وریفای شده</p>
                                <p className={`text-little-bold`}>G2G+پی پال+سرور مجازی</p>
                            </div>
                        </div>
                        <div className={`grid justify-center items-center py-10 px-3 ${styles.boxProduct}`}>
                            <div className='grid justify-center items-center'>
                                <img src="/images/boat.svg" alt=""/>
                            </div>
                            <div className={``}>
                                <p className={`text-little-bold`}>پکیج اکانت وریفای شده</p>
                                <p className={`text-little-bold`}>G2G+پی پال+سرور مجازی</p>
                            </div>
                        </div>
                        <div className={` justify-center items-center py-10 px-3 hidden xl:grid ${styles.boxProduct}`}>
                            <div className='grid justify-center items-center'>
                                <img src="/images/boat.svg" alt=""/>
                            </div>
                            <div className={``}>
                                <p className={`text-little-bold`}>پکیج اکانت وریفای شده</p>
                                <p className={`text-little-bold`}>G2G+پی پال+سرور مجازی</p>
                            </div>
                        </div>
                        <div className={`${styles.leftArrow}`}>
                            <svg width="9" height="17" viewBox="0 0 9 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.84451 15.3437L1.68918 9.6477C0.96225 8.97501 0.967768 7.88028 1.70145 7.21495L7.91388 1.5813"
                                      stroke="#959595" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                    </div>
                    <div className={`flex justify-center items-center mt-custom-2`}>
                        <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8.65046 4.50707C8.65046 5.66185 8.2609 6.60098 7.48177 7.32446C6.70264 8.04794 5.72177 8.40968 4.53916 8.40968C3.34264 8.40968 2.35481 8.04794 1.57568 7.32446C0.796549 6.60098 0.406984 5.66185 0.406984 4.50707C0.406984 3.3662 0.796549 2.43402 1.57568 1.71054C2.3409 1.00098 3.32872 0.646197 4.53916 0.646197C5.73568 0.646197 6.72351 1.00098 7.50264 1.71054C8.26785 2.43402 8.65046 3.3662 8.65046 4.50707Z"
                                fill="#DDDDDD"/>
                        </svg>
                        <svg className='mx-3' width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8.65046 4.50707C8.65046 5.66185 8.2609 6.60098 7.48177 7.32446C6.70264 8.04794 5.72177 8.40968 4.53916 8.40968C3.34264 8.40968 2.35481 8.04794 1.57568 7.32446C0.796549 6.60098 0.406984 5.66185 0.406984 4.50707C0.406984 3.3662 0.796549 2.43402 1.57568 1.71054C2.3409 1.00098 3.32872 0.646197 4.53916 0.646197C5.73568 0.646197 6.72351 1.00098 7.50264 1.71054C8.26785 2.43402 8.65046 3.3662 8.65046 4.50707Z"
                                fill="#42DB9B"/>
                        </svg>
                        <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8.83845 4.50707C8.83845 5.66185 8.44889 6.60098 7.66975 7.32446C6.89062 8.04794 5.90975 8.40968 4.72715 8.40968C3.53062 8.40968 2.5428 8.04794 1.76367 7.32446C0.984537 6.60098 0.594972 5.66185 0.594972 4.50707C0.594972 3.3662 0.984537 2.43402 1.76367 1.71054C2.52889 1.00098 3.51671 0.646197 4.72715 0.646197C5.92367 0.646197 6.91149 1.00098 7.69062 1.71054C8.45584 2.43402 8.83845 3.3662 8.83845 4.50707Z"
                                fill="#DDDDDD"/>
                        </svg>
                    </div>
                </div>

                <div className={`${styles.serviceBox} ${styles.section_sm}  items-center !pl-[55px] mr-4`}>
                    <div className={`flex huge-text-little-bold justify-between`}>
                        <div className={``}>سرویس های پیشنهادی</div>
                        <More />
                    </div>

                    <div className={` flex `}>
                        <div className={'grid xl:gap-[20px] gap-[12px]'}>
                            <div className={`flex items-center justify-between px-3 ${styles.boxesService}`}>
                                <div className={'flex items-center'}>
                                <img src="/images/apple.svg" alt="apple"/>
                                <p className={`text-very-bold mr-1 text-[#464646]`}>اکانت یک ماهه CANVA</p>
                                </div>
                                <p className={` text-[#959595] ${styles.subTitleService}`}>1 الی 5 ساعت</p>
                            </div>
                            <div className={`flex items-center border border-[#42DB9B] justify-between px-3 ${styles.boxesService}`}>
                                <div className={'flex items-center'}>
                                <img src="/images/star.svg" alt="apple"/>
                                <p className={`text-very-bold mr-1 text-[#464646]`}>اکانت یک ماهه CANVA</p>
                                </div>
                                <p className={` text-[#959595] ${styles.subTitleService}`}>1 الی 5 ساعت</p>
                            </div>
                            <div className={`flex items-center justify-between px-3 ${styles.boxesService}`}>
                                <div className={'flex items-center'}>
                                <img src="/images/canwa.svg" alt="apple"/>
                                <p className={`text-very-bold mr-1 text-[#464646]`}>اکانت یک ماهه CANVA</p>
                                </div>
                                <p className={` text-[#959595] ${styles.subTitleService}`}>1 الی 5 ساعت</p>
                            </div>
                        </div>
                    </div>


                    <div className={`grid absolute items-center justify-center top-[50%] translate-y-[-50%] left-[15px] gap-[12px]`}>
                        <div>
                            <svg className='mt-4' width="17" height="9" viewBox="0 0 17 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.35267 7.79397L7.04867 1.63865C7.72135 0.911713 8.81609 0.917231 9.48141 1.65091L15.1151 7.86334"
                                      stroke="#DDDDDD" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div className='grid justify-center gap-[5px]'>
                            <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M4.21208 8.50965C3.0573 8.50965 2.11817 8.12009 1.39469 7.34096C0.671211 6.56183 0.309472 5.58096 0.309472 4.39835C0.309472 3.20183 0.671211 2.214 1.39469 1.43487C2.11817 0.655741 3.0573 0.266176 4.21208 0.266176C5.35295 0.266176 6.28512 0.655741 7.0086 1.43487C7.71817 2.20009 8.07295 3.18792 8.07295 4.39835C8.07295 5.59487 7.71817 6.5827 7.0086 7.36183C6.28512 8.12705 5.35295 8.50965 4.21208 8.50965Z"
                                    fill="#DDDDDD"/>
                            </svg>
                            <svg className={`my-2`} width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M4.21208 8.50965C3.0573 8.50965 2.11817 8.12009 1.39469 7.34096C0.671211 6.56183 0.309472 5.58096 0.309472 4.39835C0.309472 3.20183 0.671211 2.214 1.39469 1.43487C2.11817 0.655741 3.0573 0.266176 4.21208 0.266176C5.35295 0.266176 6.28512 0.655741 7.0086 1.43487C7.71817 2.20009 8.07295 3.18792 8.07295 4.39835C8.07295 5.59487 7.71817 6.5827 7.0086 7.36183C6.28512 8.12705 5.35295 8.50965 4.21208 8.50965Z"
                                    fill="#42DB9B"/>
                            </svg>
                            <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M4.21208 8.50965C3.0573 8.50965 2.11817 8.12009 1.39469 7.34096C0.671211 6.56183 0.309472 5.58096 0.309472 4.39835C0.309472 3.20183 0.671211 2.214 1.39469 1.43487C2.11817 0.655741 3.0573 0.266176 4.21208 0.266176C5.35295 0.266176 6.28512 0.655741 7.0086 1.43487C7.71817 2.20009 8.07295 3.18792 8.07295 4.39835C8.07295 5.59487 7.71817 6.5827 7.0086 7.36183C6.28512 8.12705 5.35295 8.50965 4.21208 8.50965Z"
                                    fill="#DDDDDD"/>
                            </svg>
                        </div>
                        <div>
                            <svg width="17" height="9" viewBox="0 0 17 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15.1321 1.09698L9.46723 7.28094C8.79821 8.01126 7.70346 8.01126 7.03445 7.28094L1.36955 1.09698"
                                      stroke="#DDDDDD" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                            </svg>
                        </div>
                    </div>

                </div>
            </div>

            {/*<div className={`my-5 py-5 bg-black`}>
                <CryptoChart symbol="BTCUSDT" />
            </div>*/}

            <div className={`${styles.services} mt-custom-4 grid section !pb-4`}>

                <div className={`flex justify-between items-center huge-text-little-bold`}>
                    <div className={`text-[#2E2E2E]`}>سرویس ها</div>
                    <More />
                </div>

                <div className={`flex items-center`}>
                    <div className={`!translate-y-[-18%] ${styles.rightArrow}`}>
                        <svg width="10" height="17" viewBox="0 0 10 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1.54651 1.88745L7.73047 7.55235C8.46078 8.22136 8.46078 9.31611 7.73047 9.98513L1.54651 15.65" stroke="#959595"
                                  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <div className='flex xl:gap-[50px] !justify-between gap-[20px] w-full'>
                        <div className='flex items-center'>
                            <img src="/images/img.svg" alt=""/>
                            <p className='text-very-bold mr-2'>اکانت یک ماهه CANVA</p>
                        </div>
                        <div className='flex items-center '>
                            <img src="/images/img2.svg" alt=""/>
                            <p className='text-very-bold mr-2'>اکانت یک ماهه CANVA</p>
                        </div>
                        <div className='flex items-center '>
                            <img src="/images/spotify.svg" alt=""/>
                            <p className='text-very-bold mr-2'>اکانت یک ماهه CANVA</p>
                        </div>
                        <div className='flex items-center '>
                            <img src="/images/jem.svg" alt=""/>
                            <p className='text-very-bold mr-2'>اکانت یک ماهه CANVA</p>
                        </div>
                        <div className=' items-center  hidden xl:flex'>
                            <img src="/images/twitch.svg" alt=""/>
                            <p className='text-very-bold mr-2'>اکانت یک ماهه CANVA</p>
                        </div>
                    </div>
                    <div className={`!translate-y-[-18%] ${styles.leftArrow}`}>
                        <svg width="10" height="17" viewBox="0 0 10 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.35526 15.6669L2.19994 9.97094C1.47301 9.29826 1.47853 8.20352 2.2122 7.5382L8.42464 1.90454" stroke="#959595"
                                  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </div>
                <div className={`flex justify-center items-center mt-custom-3`}>
                    <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.65046 4.50707C8.65046 5.66185 8.2609 6.60098 7.48177 7.32446C6.70264 8.04794 5.72177 8.40968 4.53916 8.40968C3.34264 8.40968 2.35481 8.04794 1.57568 7.32446C0.796549 6.60098 0.406984 5.66185 0.406984 4.50707C0.406984 3.3662 0.796549 2.43402 1.57568 1.71054C2.3409 1.00098 3.32872 0.646197 4.53916 0.646197C5.73568 0.646197 6.72351 1.00098 7.50264 1.71054C8.26785 2.43402 8.65046 3.3662 8.65046 4.50707Z"
                            fill="#DDDDDD"/>
                    </svg>
                    <svg className='mx-3' width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.65046 4.50707C8.65046 5.66185 8.2609 6.60098 7.48177 7.32446C6.70264 8.04794 5.72177 8.40968 4.53916 8.40968C3.34264 8.40968 2.35481 8.04794 1.57568 7.32446C0.796549 6.60098 0.406984 5.66185 0.406984 4.50707C0.406984 3.3662 0.796549 2.43402 1.57568 1.71054C2.3409 1.00098 3.32872 0.646197 4.53916 0.646197C5.73568 0.646197 6.72351 1.00098 7.50264 1.71054C8.26785 2.43402 8.65046 3.3662 8.65046 4.50707Z"
                            fill="#42DB9B"/>
                    </svg>
                    <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.83845 4.50707C8.83845 5.66185 8.44889 6.60098 7.66975 7.32446C6.89062 8.04794 5.90975 8.40968 4.72715 8.40968C3.53062 8.40968 2.5428 8.04794 1.76367 7.32446C0.984537 6.60098 0.594972 5.66185 0.594972 4.50707C0.594972 3.3662 0.984537 2.43402 1.76367 1.71054C2.52889 1.00098 3.51671 0.646197 4.72715 0.646197C5.92367 0.646197 6.91149 1.00098 7.69062 1.71054C8.45584 2.43402 8.83845 3.3662 8.83845 4.50707Z"
                            fill="#DDDDDD"/>
                    </svg>
                </div>
            </div>


            <div className='mt-custom-4 relative'>
                <img src="/images/img3.svg" alt="" className={'w-full'}/>
                <div className={`grid justify-center items-center absolute ${styles.boxBtnDetails}`}>
                    <p className='text-[#FFFFFF] font-bold text-[1.5rem]'>هم اکنون <span className='text-[#42DB9B]'>تجارت</span> کنید</p>
                    <button className={`${styles.btnDetails} mx-auto text-sm !w-[138px] text-very-bold bg-[#42DB9B] text-[#FFFFFF] py-2 rounded-[10px] mt-3`}>مشاهده
                        جزئیات
                    </button>
                </div>
            </div>

            <div className={`${styles.giftCard} mt-custom-4 section`}>
                <div className={`flex huge-text-little-bold  justify-between items-center`}>
                    <div className={`text-[#2E2E2E]`}>گیفت کارت</div>
                    <More />
                </div>
                <div className='grid grid-cols-4 items-center justify-center xl:gap-10 gap-5'>
                    <div className={styles.rightArrow}>
                        <svg width="10" height="17" viewBox="0 0 10 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1.28394 1.56427L7.46789 7.22917C8.19821 7.89818 8.19821 8.99293 7.46789 9.66195L1.28394 15.3268"
                                  stroke="#959595" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <Card title={'twitch'} text={'گیفت تویچ ویژه مشترکین'} img="/images/twitchBig.svg" />
                    <Card title={'twitch'} text={'گیفت تویچ ویژه مشترکین'} img="/images/spotifyBig.svg" />
                    <Card title={'twitch'} text={'گیفت تویچ ویژه مشترکین'} img="/images/steam.svg" />
                    <Card title={'twitch'} text={'گیفت تویچ ویژه مشترکین'} img="/images/xBox.svg" />
                    <div className={styles.leftArrow}>
                        <svg width="9" height="17" viewBox="0 0 9 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.84451 15.3437L1.68918 9.6477C0.96225 8.97501 0.967768 7.88028 1.70145 7.21495L7.91388 1.5813" stroke="#959595"
                                  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </div>
                <div className={`flex justify-center items-center mt-custom-2`}>
                    <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.65046 4.50707C8.65046 5.66185 8.2609 6.60098 7.48177 7.32446C6.70264 8.04794 5.72177 8.40968 4.53916 8.40968C3.34264 8.40968 2.35481 8.04794 1.57568 7.32446C0.796549 6.60098 0.406984 5.66185 0.406984 4.50707C0.406984 3.3662 0.796549 2.43402 1.57568 1.71054C2.3409 1.00098 3.32872 0.646197 4.53916 0.646197C5.73568 0.646197 6.72351 1.00098 7.50264 1.71054C8.26785 2.43402 8.65046 3.3662 8.65046 4.50707Z"
                            fill="#DDDDDD"/>
                    </svg>
                    <svg className='mx-3' width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.65046 4.50707C8.65046 5.66185 8.2609 6.60098 7.48177 7.32446C6.70264 8.04794 5.72177 8.40968 4.53916 8.40968C3.34264 8.40968 2.35481 8.04794 1.57568 7.32446C0.796549 6.60098 0.406984 5.66185 0.406984 4.50707C0.406984 3.3662 0.796549 2.43402 1.57568 1.71054C2.3409 1.00098 3.32872 0.646197 4.53916 0.646197C5.73568 0.646197 6.72351 1.00098 7.50264 1.71054C8.26785 2.43402 8.65046 3.3662 8.65046 4.50707Z"
                            fill="#42DB9B"/>
                    </svg>
                    <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.83845 4.50707C8.83845 5.66185 8.44889 6.60098 7.66975 7.32446C6.89062 8.04794 5.90975 8.40968 4.72715 8.40968C3.53062 8.40968 2.5428 8.04794 1.76367 7.32446C0.984537 6.60098 0.594972 5.66185 0.594972 4.50707C0.594972 3.3662 0.984537 2.43402 1.76367 1.71054C2.52889 1.00098 3.51671 0.646197 4.72715 0.646197C5.92367 0.646197 6.91149 1.00098 7.69062 1.71054C8.45584 2.43402 8.83845 3.3662 8.83845 4.50707Z"
                            fill="#DDDDDD"/>
                    </svg>
                </div>
            </div>

            <div className='grid xl:grid-cols-3 grid-cols-2 xl:gap-[20px] gap-[12px] mt-custom-4 justify-center items-center'>
                <div className={`${styles.boxAmazoneCard}`}>
                    <div className='grid justify-center items-center'>
                        <img src="/images/car.svg" alt=""/>
                    </div>
                    <div className={`text-center`}>
                        <p className={`Largest-text-little-bold text-[#464646]`}>خرید مستقیم از امازون انگلیس</p>
                        <p className={`text-[0.625rem] mt-1.5 text-[#959595]`}>با بهترین قیمت محصول مورد</p>
                        <p className='text-[0.625rem] text-[#959595]'>علاقه خود را سفارش دهید</p>
                    </div>
                </div>
                <div className={`${styles.boxAmazoneCard} ${styles.active}`}>
                    <div className='grid justify-center items-center'>
                        <img src="/images/telephone.svg" alt=""/>
                    </div>
                    <div className={`text-center`}>
                        <p className={`Largest-text-little-bold text-[#464646]`}>خرید مستقیم از امازون انگلیس</p>
                        <p className={`text-[0.625rem] mt-1.5 text-[#959595]`}>با بهترین قیمت محصول مورد</p>
                        <p className='text-[0.625rem] text-[#959595]'>علاقه خود را سفارش دهید</p>
                    </div>
                </div>
                <div className={`${styles.boxAmazoneCard}`}>
                    <div className='grid justify-center items-center'>
                        <img src="/images/truck.svg" alt=""/>
                    </div>
                    <div className={`text-center`}>
                        <p className={`Largest-text-little-bold text-[#464646]`}>خرید مستقیم از امازون انگلیس</p>
                        <p className={`text-[0.625rem] mt-1.5 text-[#959595]`}>با بهترین قیمت محصول مورد</p>
                        <p className='text-[0.625rem] text-[#959595]'>علاقه خود را سفارش دهید</p>
                    </div>
                </div>
            </div>

            <div className={`mt-custom-4 section`}>
            <div className={`flex huge-text-little-bold justify-between items-center`}>
                    <p className={` text-[#2E2E2E]`}>اخبار پیشنهادی</p>
                    <More />
                </div>
                <div className='grid xl:grid-cols-3 grid-cols-2 gap-[22px]'>
                    <div className={`${styles.news}`}>
                        <div className='grid justify-center items-center'>
                            <img src="/images/binance.png" className={"w-full max-h-[210px] object-cover rounded-[20px]"} alt=""/>
                        </div>
                        <div className='flex justify-start gap-[22px] mt-5'>
                            <div className='flex'>
                                <svg width="20" height="23" viewBox="0 0 20 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7 1.59521C7 1.04293 6.55228 0.595215 6 0.595215C5.44772 0.595215 5 1.04293 5 1.59521H7ZM5 5.59521C5 6.1475 5.44772 6.59521 6 6.59521C6.55228 6.59521 7 6.1475 7 5.59521H5ZM15 1.59521C15 1.04293 14.5523 0.595215 14 0.595215C13.4477 0.595215 13 1.04293 13 1.59521H15ZM13 5.59521C13 6.1475 13.4477 6.59521 14 6.59521C14.5523 6.59521 15 6.1475 15 5.59521H13ZM10 14.5952C9.44771 14.5952 9 15.0429 9 15.5952C9 16.1475 9.44771 16.5952 10 16.5952V14.5952ZM10.01 16.5952C10.5623 16.5952 11.01 16.1475 11.01 15.5952C11.01 15.0429 10.5623 14.5952 10.01 14.5952V16.5952ZM14 14.5952C13.4477 14.5952 13 15.0429 13 15.5952C13 16.1475 13.4477 16.5952 14 16.5952V14.5952ZM14.01 16.5952C14.5623 16.5952 15.01 16.1475 15.01 15.5952C15.01 15.0429 14.5623 14.5952 14.01 14.5952V16.5952ZM6 14.5952C5.44772 14.5952 5 15.0429 5 15.5952C5 16.1475 5.44772 16.5952 6 16.5952V14.5952ZM6.01 16.5952C6.56228 16.5952 7.01 16.1475 7.01 15.5952C7.01 15.0429 6.56228 14.5952 6.01 14.5952V16.5952ZM4 4.59521H16V2.59521H4V4.59521ZM18 6.59521V18.5952H20V6.59521H18ZM16 20.5952H4V22.5952H16V20.5952ZM2 18.5952V6.59522H0V18.5952H2ZM4 20.5952C2.89543 20.5952 2 19.6998 2 18.5952H0C0 20.8044 1.79086 22.5952 4 22.5952V20.5952ZM18 18.5952C18 19.6998 17.1046 20.5952 16 20.5952V22.5952C18.2091 22.5952 20 20.8044 20 18.5952H18ZM16 4.59521C17.1046 4.59521 18 5.49065 18 6.59521H20C20 4.38608 18.2091 2.59521 16 2.59521V4.59521ZM4 2.59521C1.79086 2.59521 0 4.38608 0 6.59522H2C2 5.49065 2.89543 4.59521 4 4.59521V2.59521ZM1 10.5952H19V8.59521H1V10.5952ZM5 1.59521V5.59521H7V1.59521H5ZM13 1.59521V5.59521H15V1.59521H13ZM10 16.5952H10.01V14.5952H10V16.5952ZM14 16.5952H14.01V14.5952H14V16.5952ZM6 16.5952H6.01V14.5952H6V16.5952Z"
                                        fill="#959595"/>
                                </svg>
                                <p className='Largest-text-little-bold mr-2 text-[#959595]'>13 اسفند 1403</p>
                            </div>
                            <div className='flex items-center'>
                                <svg width="23" height="18" viewBox="0 0 23 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.36951 9.41721C1.3005 9.2098 1.3005 8.98562 1.36951 8.77821C2.75651 4.60521 6.69351 1.59521 11.3335 1.59521C15.9715 1.59521 19.9065 4.60222 21.2965 8.77322C21.3665 8.98022 21.3665 9.20422 21.2965 9.41222C19.9105 13.5852 15.9735 16.5952 11.3335 16.5952C6.69551 16.5952 2.75951 13.5882 1.36951 9.41721Z"
                                        stroke="#959595" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path
                                        d="M14.3334 9.09521C14.3334 9.89086 14.0173 10.6539 13.4547 11.2165C12.8921 11.7791 12.129 12.0952 11.3334 12.0952C10.5377 12.0952 9.77466 11.7791 9.21205 11.2165C8.64944 10.6539 8.33337 9.89086 8.33337 9.09521C8.33337 8.29957 8.64944 7.5365 9.21205 6.97389C9.77466 6.41128 10.5377 6.09521 11.3334 6.09521C12.129 6.09521 12.8921 6.41128 13.4547 6.97389C14.0173 7.5365 14.3334 8.29957 14.3334 9.09521Z"
                                        stroke="#959595" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <p className='Largest-text-little-bold mr-2 text-[#959595]'>2657 بازدید</p>
                            </div>
                        </div>
                        <div className={`text-start mt-2`}>
                            <p className={`Largest-text-little-bold text-[#464646]`}>
                                تسلط بایننس بر استیبل کوین ها رمز موفقیت
                                در بازار...</p>
                        </div>
                    </div>
                    <div className={`${styles.news}`}>
                        <div className='grid justify-center items-center'>
                            <img src="/images/binance.png" className={"w-full max-h-[210px] object-cover rounded-[20px]"} alt=""/>
                        </div>
                        <div className='flex justify-start gap-[22px] mt-5'>
                            <div className='flex'>
                                <svg width="20" height="23" viewBox="0 0 20 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7 1.59521C7 1.04293 6.55228 0.595215 6 0.595215C5.44772 0.595215 5 1.04293 5 1.59521H7ZM5 5.59521C5 6.1475 5.44772 6.59521 6 6.59521C6.55228 6.59521 7 6.1475 7 5.59521H5ZM15 1.59521C15 1.04293 14.5523 0.595215 14 0.595215C13.4477 0.595215 13 1.04293 13 1.59521H15ZM13 5.59521C13 6.1475 13.4477 6.59521 14 6.59521C14.5523 6.59521 15 6.1475 15 5.59521H13ZM10 14.5952C9.44771 14.5952 9 15.0429 9 15.5952C9 16.1475 9.44771 16.5952 10 16.5952V14.5952ZM10.01 16.5952C10.5623 16.5952 11.01 16.1475 11.01 15.5952C11.01 15.0429 10.5623 14.5952 10.01 14.5952V16.5952ZM14 14.5952C13.4477 14.5952 13 15.0429 13 15.5952C13 16.1475 13.4477 16.5952 14 16.5952V14.5952ZM14.01 16.5952C14.5623 16.5952 15.01 16.1475 15.01 15.5952C15.01 15.0429 14.5623 14.5952 14.01 14.5952V16.5952ZM6 14.5952C5.44772 14.5952 5 15.0429 5 15.5952C5 16.1475 5.44772 16.5952 6 16.5952V14.5952ZM6.01 16.5952C6.56228 16.5952 7.01 16.1475 7.01 15.5952C7.01 15.0429 6.56228 14.5952 6.01 14.5952V16.5952ZM4 4.59521H16V2.59521H4V4.59521ZM18 6.59521V18.5952H20V6.59521H18ZM16 20.5952H4V22.5952H16V20.5952ZM2 18.5952V6.59522H0V18.5952H2ZM4 20.5952C2.89543 20.5952 2 19.6998 2 18.5952H0C0 20.8044 1.79086 22.5952 4 22.5952V20.5952ZM18 18.5952C18 19.6998 17.1046 20.5952 16 20.5952V22.5952C18.2091 22.5952 20 20.8044 20 18.5952H18ZM16 4.59521C17.1046 4.59521 18 5.49065 18 6.59521H20C20 4.38608 18.2091 2.59521 16 2.59521V4.59521ZM4 2.59521C1.79086 2.59521 0 4.38608 0 6.59522H2C2 5.49065 2.89543 4.59521 4 4.59521V2.59521ZM1 10.5952H19V8.59521H1V10.5952ZM5 1.59521V5.59521H7V1.59521H5ZM13 1.59521V5.59521H15V1.59521H13ZM10 16.5952H10.01V14.5952H10V16.5952ZM14 16.5952H14.01V14.5952H14V16.5952ZM6 16.5952H6.01V14.5952H6V16.5952Z"
                                        fill="#959595"/>
                                </svg>
                                <p className='Largest-text-little-bold mr-2 text-[#959595]'>13 اسفند 1403</p>
                            </div>
                            <div className='flex items-center'>
                                <svg width="23" height="18" viewBox="0 0 23 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.36951 9.41721C1.3005 9.2098 1.3005 8.98562 1.36951 8.77821C2.75651 4.60521 6.69351 1.59521 11.3335 1.59521C15.9715 1.59521 19.9065 4.60222 21.2965 8.77322C21.3665 8.98022 21.3665 9.20422 21.2965 9.41222C19.9105 13.5852 15.9735 16.5952 11.3335 16.5952C6.69551 16.5952 2.75951 13.5882 1.36951 9.41721Z"
                                        stroke="#959595" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path
                                        d="M14.3334 9.09521C14.3334 9.89086 14.0173 10.6539 13.4547 11.2165C12.8921 11.7791 12.129 12.0952 11.3334 12.0952C10.5377 12.0952 9.77466 11.7791 9.21205 11.2165C8.64944 10.6539 8.33337 9.89086 8.33337 9.09521C8.33337 8.29957 8.64944 7.5365 9.21205 6.97389C9.77466 6.41128 10.5377 6.09521 11.3334 6.09521C12.129 6.09521 12.8921 6.41128 13.4547 6.97389C14.0173 7.5365 14.3334 8.29957 14.3334 9.09521Z"
                                        stroke="#959595" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <p className='Largest-text-little-bold mr-2 text-[#959595]'>2657 بازدید</p>
                            </div>
                        </div>
                        <div className={`text-start mt-2`}>
                            <p className={`Largest-text-little-bold text-[#464646]`}>
                                تسلط بایننس بر استیبل کوین ها رمز موفقیت
                                در بازار...</p>
                        </div>
                    </div>
                    <div className={`${styles.news}`}>
                        <div className='grid justify-center items-center'>
                            <img src="/images/binance.png" className={"w-full max-h-[210px] object-cover rounded-[20px]"} alt="" />
                        </div>
                        <div className='flex justify-start gap-[22px] mt-5'>
                            <div className='flex'>
                                <svg width="20" height="23" viewBox="0 0 20 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7 1.59521C7 1.04293 6.55228 0.595215 6 0.595215C5.44772 0.595215 5 1.04293 5 1.59521H7ZM5 5.59521C5 6.1475 5.44772 6.59521 6 6.59521C6.55228 6.59521 7 6.1475 7 5.59521H5ZM15 1.59521C15 1.04293 14.5523 0.595215 14 0.595215C13.4477 0.595215 13 1.04293 13 1.59521H15ZM13 5.59521C13 6.1475 13.4477 6.59521 14 6.59521C14.5523 6.59521 15 6.1475 15 5.59521H13ZM10 14.5952C9.44771 14.5952 9 15.0429 9 15.5952C9 16.1475 9.44771 16.5952 10 16.5952V14.5952ZM10.01 16.5952C10.5623 16.5952 11.01 16.1475 11.01 15.5952C11.01 15.0429 10.5623 14.5952 10.01 14.5952V16.5952ZM14 14.5952C13.4477 14.5952 13 15.0429 13 15.5952C13 16.1475 13.4477 16.5952 14 16.5952V14.5952ZM14.01 16.5952C14.5623 16.5952 15.01 16.1475 15.01 15.5952C15.01 15.0429 14.5623 14.5952 14.01 14.5952V16.5952ZM6 14.5952C5.44772 14.5952 5 15.0429 5 15.5952C5 16.1475 5.44772 16.5952 6 16.5952V14.5952ZM6.01 16.5952C6.56228 16.5952 7.01 16.1475 7.01 15.5952C7.01 15.0429 6.56228 14.5952 6.01 14.5952V16.5952ZM4 4.59521H16V2.59521H4V4.59521ZM18 6.59521V18.5952H20V6.59521H18ZM16 20.5952H4V22.5952H16V20.5952ZM2 18.5952V6.59522H0V18.5952H2ZM4 20.5952C2.89543 20.5952 2 19.6998 2 18.5952H0C0 20.8044 1.79086 22.5952 4 22.5952V20.5952ZM18 18.5952C18 19.6998 17.1046 20.5952 16 20.5952V22.5952C18.2091 22.5952 20 20.8044 20 18.5952H18ZM16 4.59521C17.1046 4.59521 18 5.49065 18 6.59521H20C20 4.38608 18.2091 2.59521 16 2.59521V4.59521ZM4 2.59521C1.79086 2.59521 0 4.38608 0 6.59522H2C2 5.49065 2.89543 4.59521 4 4.59521V2.59521ZM1 10.5952H19V8.59521H1V10.5952ZM5 1.59521V5.59521H7V1.59521H5ZM13 1.59521V5.59521H15V1.59521H13ZM10 16.5952H10.01V14.5952H10V16.5952ZM14 16.5952H14.01V14.5952H14V16.5952ZM6 16.5952H6.01V14.5952H6V16.5952Z"
                                        fill="#959595"/>
                                </svg>
                                <p className='Largest-text-little-bold mr-2 text-[#959595]'>13 اسفند 1403</p>
                            </div>
                            <div className='flex items-center'>
                                <svg width="23" height="18" viewBox="0 0 23 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.36951 9.41721C1.3005 9.2098 1.3005 8.98562 1.36951 8.77821C2.75651 4.60521 6.69351 1.59521 11.3335 1.59521C15.9715 1.59521 19.9065 4.60222 21.2965 8.77322C21.3665 8.98022 21.3665 9.20422 21.2965 9.41222C19.9105 13.5852 15.9735 16.5952 11.3335 16.5952C6.69551 16.5952 2.75951 13.5882 1.36951 9.41721Z"
                                        stroke="#959595" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path
                                        d="M14.3334 9.09521C14.3334 9.89086 14.0173 10.6539 13.4547 11.2165C12.8921 11.7791 12.129 12.0952 11.3334 12.0952C10.5377 12.0952 9.77466 11.7791 9.21205 11.2165C8.64944 10.6539 8.33337 9.89086 8.33337 9.09521C8.33337 8.29957 8.64944 7.5365 9.21205 6.97389C9.77466 6.41128 10.5377 6.09521 11.3334 6.09521C12.129 6.09521 12.8921 6.41128 13.4547 6.97389C14.0173 7.5365 14.3334 8.29957 14.3334 9.09521Z"
                                        stroke="#959595" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <p className='Largest-text-little-bold mr-2 text-[#959595]'>2657 بازدید</p>
                            </div>
                        </div>
                        <div className={`text-start mt-2`}>
                            <p className={`Largest-text-little-bold text-[#464646]`}>
                                تسلط بایننس بر استیبل کوین ها رمز موفقیت
                                در بازار...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}