export default function Footer() {
    return (
        <>
            <svg width="1922" height="48" viewBox="0 0 1922 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path opacity="0.02" d="M1 40C1 40 585.888 8 961 8C1336.11 8 1921 40 1921 40" stroke="#28303F" stroke-width="16" />
            </svg>

            <div className="text-center text-4xl text-blue-custom">
                footer
            </div>
        </>
    );
}